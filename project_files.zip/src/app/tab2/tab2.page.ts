import { Component } from '@angular/core';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  standalone: false,
})
export class Tab2Page {

  ingressos = [
    {
      nome: 'Festival de Inverno 2024',
      data: '15 Julho',
      codigo: 'TKT-99283',
      imagem: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=500&q=80'
    }
  ];

  constructor() {}

}
