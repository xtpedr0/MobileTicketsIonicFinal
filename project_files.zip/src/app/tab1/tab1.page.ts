import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: false,
})
export class Tab1Page {

  eventos = [
    {
      nome: 'Festival de Inverno 2024',
      data: '15 Julho',
      local: 'Parque da Cidade',
      preco: '80,00',
      descricao: 'O maior festival de música e cultura da região.',
      imagem: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=500&q=80'
    },
    {
      nome: 'Show Rock in Rio Cover',
      data: '22 Agosto',
      local: 'Arena Central',
      preco: '45,00',
      descricao: 'As melhores bandas cover do país reunidas em um só lugar.',
      imagem: 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?w=500&q=80'
    },
    {
      nome: 'Stand-up Comedy Night',
      data: '05 Setembro',
      local: 'Teatro Municipal',
      preco: '30,00',
      descricao: 'Uma noite de muitas risadas com os melhores comediantes.',
      imagem: 'https://images.unsplash.com/photo-1514525253361-bee8718a34e1?w=500&q=80'
    }
  ];

  constructor() {}

}
