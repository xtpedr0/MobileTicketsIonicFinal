# MobileTicketsIonic

Aplicação mobile para compra e gerenciamento de ingressos desenvolvida com **Ionic Framework**, **Angular (ngModules)** e **Capacitor**.

## 🚀 Tecnologias Utilizadas

- **Ionic CLI**: 7.2.0
- **Angular**: 17.x (com NgModules)
- **Capacitor**: Integração nativa
- **TypeScript**: Linguagem base
- **Sass**: Estilização

## 📱 Funcionalidades

- **Explorar Eventos**: Lista de eventos disponíveis com detalhes e preços.
- **Meus Ingressos**: Visualização dos ingressos adquiridos pelo usuário.
- **Perfil**: Gerenciamento de informações da conta do usuário.

## 📸 Screenshots

Abaixo estão algumas capturas de tela da aplicação:

### 1. Lista de Eventos (Tab 1)
![Lista de Eventos](./screenshots/screen1.webp)

### 2. Meus Ingressos (Tab 2)
![Meus Ingressos](./screenshots/screen2.webp)

### 3. Perfil do Usuário (Tab 3)
![Perfil](./screenshots/screen3.webp)

## 🛠️ Como Executar o Projeto

1. Clone o repositório:
   ```bash
   git clone https://github.com/xtpedr0/MobileTicketsIonicFinal.git
   ```

2. Entre na pasta do projeto:
   ```bash
   cd MobileTicketsIonicFinal
   ```

3. Instale as dependências:
   ```bash
   npm install
   ```

4. Execute a aplicação no navegador:
   ```bash
   ionic serve
   ```

## 📄 Licença

Este projeto está sob a licença **MIT**. Veja o arquivo [LICENSE](./LICENSE) para mais detalhes.
